<?php return array (
  'phase1.phase1-list' => 'App\\Http\\Livewire\\Phase1\\Phase1List',
  'phase2a-list' => 'App\\Http\\Livewire\\Phase2aList',
  'user-list' => 'App\\Http\\Livewire\\UserList',
);