

<input

    x-data

    x-ref="input"

    x-init="new Pikaday({ field: $refs.input , format: 'YYYY-MM-DD'})"

    type="text"

    <?php echo e($attributes); ?>


><?php /**PATH C:\xampp\htdocs\magellancase\resources\views/components/datepicker.blade.php ENDPATH**/ ?>