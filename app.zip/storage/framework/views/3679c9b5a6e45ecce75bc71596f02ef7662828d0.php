<div wire:loading class="bg-indigo-500 w-full z-1 p-2 text-center text-white fixed">
  <p>Processing...</p>
</div><?php /**PATH C:\xampp\htdocs\magellancase\resources\views/components/wireloading.blade.php ENDPATH**/ ?>