<div class="w-full overflow-hidden rounded-lg shadow-xs">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.wireloading','data' => []]); ?>
<?php $component->withName('wireloading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if(session()->has('message')): ?>
        <?php echo session('message'); ?>

    <?php endif; ?>

    <div class="w-full overflow-x-auto">
        <table class="w-full whitespace-no-wrap">
            <thead>
                <tr
                    class="text-xs font-semibold tracking-wide text-left text-gray-500 border-b dark:border-gray-700 bg-gray-400 dark:text-gray-400">
                    <th class="px-4 py-3 bg-gray-400" rowspan="2">ENTITY</th>
                    
                    <th></th>
                    <th></th>
                    <th class="px-4 py-3 border text-center text-white" colspan="3">Deth Certificate</th>
                    <th class="px-4 py-3 border text-center text-white" colspan="3">Petition for Probate</th>
                    <th class="px-4 py-3 border text-center text-white" colspan="3">Swearing In</th>
                    <th class="px-4 py-3 border text-center text-white" colspan="3">Short Certificate</th>
                    <th class="px-4 py-3 border text-center text-white" colspan="3">Recovery Claim Package</th>
                    <th class="px-4 py-3 border text-center text-white" colspan="3"></th>
                    

                </tr>
                <tr
                    class="text-xs font-semibold tracking-wide text-left text-gray-500 border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">

                    <th class="px-4 py-3 border">Action</th>
                    <th class="px-4 py-3 border">Case Number</th>
                    <th class="px-4 py-3 border">Orderd</th>
                    <th class="px-4 py-3 border">Received</th>
                    <th class="px-4 py-3 border">Comments</th>

                    <th class="px-4 py-3 border-2 bg-gray-400 text-white">Submitted</th>
                    <th class="px-4 py-3 border-2 bg-gray-400 text-white">Approved</th>
                    <th class="px-4 py-3 border-2 bg-gray-400 text-white">Comments</th>

                    <th class="px-4 py-3 border">Scheduled</th>
                    <th class="px-4 py-3 border">Completed</th>
                    <th class="px-4 py-3 border">Comments</th>

                    <th class="px-4 py-3 border bg-gray-400 text-white">Ordered</th>
                    <th class="px-4 py-3 border bg-gray-400 text-white">Received</th>
                    <th class="px-4 py-3 border bg-gray-400 text-white">Comments</th>

                    <th class="px-4 py-3 border">Mailed</th>
                    <th class="px-4 py-3 border">Received</th>
                    <th class="px-4 py-3 border">Comments</th>

                    <th class="px-4 py-3 border bg-gray-400 text-white">Status</th>


                </tr>
            </thead>
            <tbody class="inlineTableBorder">

                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                

                    <tr class="text-gray-700 dark:text-gray-400">
                        <td class="px-4 py-3 bg-gray-400">
                            <?php echo e($row->name); ?> (<?php echo e($row->id); ?>)
                        </td>
                        <td class="text-center border">
                            <?php if($editPhaseIndex === $row->id): ?>
                              
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:click.prevent' => 'savePhase('.e($row->id).')']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'savePhase('.e($row->id).')']); ?><i
                                        class="fa fa-check"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:click.prevent' => 'cancelPhase('.e($row->id).')']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click.prevent' => 'cancelPhase('.e($row->id).')']); ?><i
                                        class="fa fa-times"></i> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>

                            <a href="#" wire:click.prevent="editPhase(<?php echo e($row->id); ?>)"><i class="fa fa-edit"></i></a>

                                
                            <?php endif; ?>
                        </td>

                        <td class="whitespace-nowrap px-4 py-3 text-sm border relative">

                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php echo e($row->phase2a->case_number); ?><br>
                                <input wire:model.lazy="phase.<?php echo e($row->id); ?>.case_number" type="text"
                                    placeholder="Case Number" class="p-1">
                            <?php else: ?>
                                <?php echo e($row->phase2a->case_number); ?>

                            <?php endif; ?>
                        </td>

                        <td class="whitespace-nowrap px-4 py-3 text-sm border relative">

                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->deth_certificate_ordered)); ?> <br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.deth_certificate_ordered','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.deth_certificate_ordered','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->deth_certificate_ordered)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-xs border">

                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->deth_certificate_received)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.deth_certificate_received','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.deth_certificate_received','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->deth_certificate_received)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap w-48 px-4 py-3 text-sm border">
                            <?php if($row->phase2a): ?>
                                <?php echo e($row->phase2a->deth_certificate_comments); ?><br>
                            <?php endif; ?>
                            <?php if($editPhaseIndex === $row->id): ?>
                                <textarea wire:model.lazy="phase.<?php echo e($row->id); ?>.deth_certificate_comments"
                                    class="border p-1"></textarea>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->deth_certificate_comments); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>


                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400 text-white">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->petition_submited)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.petition_submited','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.petition_submited','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->petition_submited)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400 text-white">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->petition_approved)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.petition_approved','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.petition_approved','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->petition_approved)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400 text-white">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->petition_comments); ?><br>
                                <?php endif; ?>
                                <textarea wire:model.lazy="phase.<?php echo e($row->id); ?>.petition_comments"
                                    class="border p-1"></textarea>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->petition_comments); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>


                        <td class="whitespace-nowrap px-4 py-3 text-sm border">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->swearing_scheduled)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.swearing_scheduled','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.swearing_scheduled','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->swearing_scheduled)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-xs border">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->swearing_completed)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.swearing_completed','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.swearing_completed','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->swearing_completed)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->swearing_comments); ?><br>
                                <?php endif; ?>
                                <textarea wire:model.lazy="phase.<?php echo e($row->id); ?>.swearing_comments"
                                    class="border p-1"></textarea>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->swearing_comments); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>


                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400 text-white">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->short_certificate_orderd)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.short_certificate_orderd','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.short_certificate_orderd','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->short_certificate_orderd)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400 text-white">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->short_certificate_received)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.short_certificate_received','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.short_certificate_received','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->short_certificate_received)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400 text-white">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->short_certificate_chomments); ?><br>
                                <?php endif; ?>
                                <textarea wire:model.lazy="phase.<?php echo e($row->id); ?>.short_certificate_chomments"
                                    class="border p-1"></textarea>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->short_certificate_chomments); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>



                        <td class="whitespace-nowrap px-4 py-3 text-sm border">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->recovery_claim_package_mailed)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.recovery_claim_package_mailed','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.recovery_claim_package_mailed','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->recovery_claim_package_mailed)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->recovery_claim_package_returned)); ?><br>
                                <?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datepicker','data' => ['wire:model.lazy' => 'phase.'.e($row->id).'.recovery_claim_package_returned','class' => 'border']]); ?>
<?php $component->withName('datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model.lazy' => 'phase.'.e($row->id).'.recovery_claim_package_returned','class' => 'border']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e(dformat($row->phase2a->recovery_claim_package_returned)); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-4 py-3 text-sm border ">
                            <?php if($editPhaseIndex === $row->id): ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->recovery_claim_package_comments); ?><br>
                                <?php endif; ?>
                                <textarea wire:model.lazy="phase.<?php echo e($row->id); ?>.recovery_claim_package_comments"
                                    class="border p-1"></textarea>
                            <?php else: ?>
                                <?php if($row->phase2a): ?>
                                    <?php echo e($row->phase2a->recovery_claim_package_comments); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </td>


                        <td class="whitespace-nowrap px-4 py-3 text-sm border bg-gray-400">
                          <?php if($editPhaseIndex === $row->id): ?>

                          <label class="block">Select Status</label>
                          <select wire:model="phase.<?php echo e($row->id); ?>.status">
                              <option value="pending" >Pending</option>
                              <option value="complete" >Complete</option>
                          </select>
                              

                          <?php else: ?>
                              <?php if($row->phase2a): ?>
                                  <span class="text-white"><?php echo e($row->phase2a->status); ?></span>
                              <?php endif; ?>
                          <?php endif; ?>
                      </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>



    </div>
    <div class="p-2">

        <?php echo e($rows->links()); ?>


    </div>


</div>
<?php /**PATH C:\xampp\htdocs\magellancase\resources\views/livewire/phase2a-list.blade.php ENDPATH**/ ?>