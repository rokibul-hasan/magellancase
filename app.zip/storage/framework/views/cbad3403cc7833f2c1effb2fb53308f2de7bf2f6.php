<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
      <?php echo e(__('Phase 2 A')); ?>

  </h2>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('phase2a-list')->html();
} elseif ($_instance->childHasBeenRendered('cd9MIYa')) {
    $componentId = $_instance->getRenderedChildComponentId('cd9MIYa');
    $componentTag = $_instance->getRenderedChildComponentTagName('cd9MIYa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cd9MIYa');
} else {
    $response = \Livewire\Livewire::mount('phase2a-list');
    $html = $response->html();
    $_instance->logRenderedChild('cd9MIYa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\magellancase\resources\views/cases/phase2a.blade.php ENDPATH**/ ?>