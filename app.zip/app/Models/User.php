<?php

namespace App\Models;

use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function userinfo()
    {
        return $this->hasOne(UsersInfo::class);
    }

    public function phase1()
    {
        return $this->hasOne(Phase1::class);
    }

    public function phase2a()
    {
        return $this->hasOne(Phase2a::class);
    }


    // public function phase1()
    // {
    //     return $this->hasOne(Phase1::class)->withDefault(function($phase1,$user){
    //         $phase1->fill([
    //             'phase1' => 'pending',
    //             'probated_estate' => 'no'
    //         ]);

    //         $user->phase1()->save($phase1);
    //     });
    // }
}
