<x-app-layout>
  <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
      {{ __('Phase 2 A') }}
  </h2>


@livewire('phase2a-list')

</x-app-layout>
